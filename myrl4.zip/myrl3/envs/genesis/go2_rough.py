# Copyright (c) 2025, Your Name
# All rights reserved.

"""Go2 walk on rough (random-uniform + slope + stairs) terrain.

Subclass of the canonical :class:`Go2WalkEnv`. Inherits the full state
+ height scan + MDP machinery and only overrides the env config to
swap the flat plane for a procedurally generated terrain.

The terrain layout (per unitree_rl_lab conventions):

* ``flat_terrain`` — flat ground (start / end tiles)
* ``random_uniform_terrain`` — random height noise (max 0.15 m)
* ``pyramid_sloped_terrain`` — smooth pyramid slope
* ``pyramid_stairs_terrain`` — 3-level step pyramid
* ``discrete_obstacles_terrain`` — randomly placed box obstacles

The robot is spawned in the central flat tile so that all four
subterrain variants are reachable within the spawn jitter.
"""

from __future__ import annotations

import torch

from envs.genesis.go2_walk import Go2WalkEnv


class Go2RoughEnv(Go2WalkEnv):
    """Go2 walk on procedurally generated rough terrain."""

    def __init__(self, num_envs: int, show_viewer: bool = False, eval_mode: bool = False) -> None:
        super().__init__(num_envs=num_envs, show_viewer=show_viewer, eval_mode=eval_mode)
        self.name = "go2_rough"

    @classmethod
    def _default_configs(cls):
        env_cfg, obs_cfg, reward_cfg, command_cfg = super()._default_configs()

        # ----------------- terrain -----------------
        env_cfg["use_terrain"] = True
        # 8x8 subterrains (8 m each → 64 m × 64 m total).
        # The outer 2 rings are flat_terrain so the robot has plenty of
        # margin before falling off the edge.  The central 4×4 area
        # contains the rough terrain variety.
        env_cfg["terrain_cfg"] = {
            "n_subterrains": (8, 8),
            "horizontal_scale": 0.1,
            "vertical_scale": 0.005,
            "subterrain_size": (8.0, 8.0),
            "subterrain_types": [
                ["flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "random_uniform_terrain", "pyramid_sloped_terrain", "pyramid_sloped_terrain", "random_uniform_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "pyramid_stairs_terrain", "discrete_obstacles_terrain", "discrete_obstacles_terrain", "pyramid_stairs_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "pyramid_stairs_terrain", "discrete_obstacles_terrain", "discrete_obstacles_terrain", "pyramid_stairs_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "random_uniform_terrain", "pyramid_sloped_terrain", "pyramid_sloped_terrain", "random_uniform_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain"],
                ["flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain", "flat_terrain"],
            ],
            "subterrain_parameters": {
                "random_uniform_terrain": {"max_height": 0.15},
                "pyramid_sloped_terrain": {"slope": 0.4, "platform_size": 1.0},
                "pyramid_stairs_terrain": {"slope": 0.5, "step_width": 0.5, "step_height": 0.08},
                "discrete_obstacles_terrain": {"max_height": 0.15, "min_size": 0.5, "max_size": 1.5, "num_rects": 8},
            },
        }

        # Spawn at the centre of the terrain (32 m, 32 m) so the robot
        # is surrounded by ~16 m of flat ground on every side before
        # reaching the rough central area, and ~24 m before the edge.
        env_cfg["base_init_pos"] = [32.0, 32.0, 0.42]
        # Wider spawn jitter (±12 m) so the robot can be born directly on
        # rough terrain, stairs or obstacles — not just on the flat centre.
        env_cfg["base_init_pos_sampling_range"] = [-12.0, 12.0]
        env_cfg["base_init_quat"] = [1.0, 0.0, 0.0, 0.0]
        # Longer episode so the robot has time to explore from the centre
        # of the 64 m terrain all the way to the rough patches or edges.
        env_cfg["episode_length_s"] = 40.0
        # Heading mode: the robot is given a *target heading angle*
        # (commands[:, 3]) and must turn to face it. The angular-velocity
        # command (commands[:, 2]) is computed automatically in
        # ``post_physics_step`` as the heading-tracking error.
        # Example: commands = [1.0, 0.0, ?, 0.0]  →  walk forward at 1 m/s
        #          while facing the +x axis (heading = 0).
        env_cfg["command_type"] = "heading"
        # Heading mode needs 4 command slots: [vx, vy, ωz, target_heading]
        command_cfg["num_commands"] = 4

        # ----------------- obs extras -----------------
        # Bigger, denser height scan for rough terrain — matches the
        # unitree_rl_lab defaults (1.6m × 1.0m × 0.1m grid = 17×11 = 187
        # points). The 1.0m × 0.8m scan inherited from go2_walk is fine
        # for flat ground but doesn't see far enough ahead for stairs /
        # obstacles. With 0.1m resolution we still detect 10cm steps.
        env_cfg["use_height_scan"] = True
        env_cfg["height_scan_cfg"] = {
            "resolution": 0.1,
            "size_x": 1.6,
            "size_y": 1.0,
        }
        # CRITICAL: ``obs_cfg`` is computed from the *parent*'s
        # ``height_scan_cfg`` (1.0m × 0.8m → 11×9 = 99 points). Since we
        # just overrode the scan to 1.6m × 1.0m (17×11 = 187 points),
        # we must also recompute ``num_obs`` / ``num_priv_obs`` so the
        # obs buffer matches the actual scan dimension. Otherwise
        # ``compute_observations`` either overwrites scan values with
        # proprioception (if scan dim > obs dim) or crashes on the
        # concatenation (if obs dim > scan dim).
        scan_cfg = env_cfg["height_scan_cfg"]
        n_x = int(round(scan_cfg["size_x"] / scan_cfg["resolution"])) + 1
        n_y = int(round(scan_cfg["size_y"] / scan_cfg["resolution"])) + 1
        scan_dim = n_x * n_y
        base_obs = 12 + 3 * env_cfg["num_dofs"]   # 48
        obs_cfg["num_obs"] = base_obs + scan_dim  # 48 + 187 = 235
        obs_cfg["num_priv_obs"] = obs_cfg["num_obs"] + env_cfg["num_dofs"]

        # Termination: only base contact terminates; thigh/calf contacts
        # are penalised but NOT terminated so the robot can learn to
        # "scrape" past obstacles instead of dying immediately.
        env_cfg["termination_if_roll_greater_than"] = 0.8
        env_cfg["termination_if_pitch_greater_than"] = 0.8
        env_cfg["use_contact_termination"] = False

        # Reward shaping inspired by walk-these-ways:
        # - Strong forward-tracking reward to break the "stop-before-obstacle" local optimum
        # - High feet-air-time to encourage lifting legs
        # - Very mild slide penalty (sliding is normal on rough terrain)
        # - Mild undesired-contacts penalty (must not dominate and scare the policy)
        # - Feet-impact-vel penalty (discourages slamming feet into the ground)
        # - Feet-clearance penalty (discourages dragging feet during swing)
        # DreamWaQ-inspired reward shaping:
        # - termination = 0  →  policy is not scared of failing
        # - feet_air_time = 0.5  →  modest lift encouragement (DreamWaQ uses 0.1)
        # - Remove feet_clearance / feet_impact_vel / feet_slide / undesired_contacts
        #   (DreamWaQ does not use them; they make the policy conservative)
        reward_cfg["reward_scales"]["track_lin_vel_xy"] = 2.5
        reward_cfg["reward_scales"]["feet_air_time"] = 0.5
        reward_cfg["reward_scales"]["termination"] = -0.0

        # DreamWaQ-style smoothness penalties (all already implemented in rewards.py)
        reward_cfg["reward_scales"]["base_height"] = -1.0
        reward_cfg["reward_scales"]["joint_acc_l2"] = -2.5e-7
        reward_cfg["reward_scales"]["action_rate_l2"] = -0.01
        reward_cfg["reward_scales"]["energy"] = -2e-5
        reward_cfg["reward_scales"]["smoothness"] = -0.01

        # Height-aware reward: penalize the robot's body being too low
        # (encourages lifting legs over obstacles). Implemented in
        # ``Go2RoughEnv._reward_terrain_base_height``; activated by
        # adding it to ``reward_scales``.
        reward_cfg["reward_scales"]["terrain_base_height"] = 1.0

        # DreamWaQ clips negative total rewards to zero so the policy never
        # learns to "lie down" to avoid penalties.
        env_cfg["only_positive_rewards"] = True

        # NOTE: terrain curriculum is disabled for now because the current
        # mylab curriculum API expects callable functions, not dict configs.
        # Re-enable once a Genesis-compatible terrain curriculum is implemented.
        env_cfg["curriculum_terms"] = {}

        # ---- domain randomisation (conservative DreamWaQ style) ----
        env_cfg["friction_range"] = [0.2, 1.5]
        env_cfg["com_displacement_range"] = [-0.05, 0.05]
        env_cfg["randomize_motor_strength"] = True
        env_cfg["motor_strength_range"] = [0.9, 1.1]
        env_cfg["randomize_base_mass"] = True
        env_cfg["added_mass_range"] = [-1.0, 2.0]
        env_cfg["randomize_kp_scale"] = True
        env_cfg["kp_scale_range"] = [0.9, 1.1]
        env_cfg["randomize_kd_scale"] = True
        env_cfg["kd_scale_range"] = [0.9, 1.1]

        # ---- vision ----
        # The rough terrain is exactly where vision is most useful
        # (stair detection, obstacle avoidance, …). Enabling it by
        # default means ``--env go2-rough`` works with **both** ``ppo``
        # and ``vision_ppo``: the former ignores the image and trains
        # state-only, the latter uses it. Camera render cost is
        # negligible (64×64 RGB, GPU-accelerated).
        env_cfg["use_vision"] = True
        env_cfg["vision_cfg"] = {
            "res": (96, 96),               # 更大分辨率，障碍物更清晰
            "fov": 100.0,                   # 稍宽视野，看到更多侧边
            "offset": (0.3, 0.0, 0.25),     # 相机更高，俯瞰更多地面
            "lookat_offset": (2.0, 0.0, -0.4),  # 看更远(2m)、更斜下，地面占画面比例更大
        }
        # The camera provides rich temporal info; no extra state history.
        obs_cfg["num_history_obs"] = 1

        return env_cfg, obs_cfg, reward_cfg, command_cfg

    def _resample_commands(self, envs_idx):
        """Heading-mode commands for rough terrain.

        The robot is asked to walk forward (vx ∈ [0, 0.6] m/s) while
        facing a *random target heading* (commands[:, 3] ∈ [-π, π]).
        The angular-velocity command (commands[:, 2]) is computed
        automatically in ``post_physics_step`` as the heading-tracking
        error, so we only need to sample vx and target_heading here.
        """
        if len(envs_idx) == 0:
            return
        self.commands[envs_idx, 0] = torch.empty(len(envs_idx), device=self.device).uniform_(0.0, 0.6)
        self.commands[envs_idx, 1] = 0.0
        # Target heading angle in radians.  0 = +x axis,  π/2 = +y axis,
        # π = -x axis,  -π/2 = -y axis.  Uniform over the full circle so
        # the policy learns to turn in *any* direction.
        self.commands[envs_idx, 3] = torch.empty(len(envs_idx), device=self.device).uniform_(-3.14, 3.14)

    def post_physics_step(self):
        """Hook: update the front-camera pose every step so it tracks the base."""
        super().post_physics_step()
        if self._use_vision and hasattr(self, "_front_camera"):
            front_pos = self.base_pos[0].cpu().numpy() + self._vision_offset
            front_lookat = front_pos + self._vision_lookat_offset
            self._front_camera.set_pose(pos=front_pos, lookat=front_lookat)

    def _reward_terrain_base_height(self):
        """Reward the base being at the right height for the terrain.

        For a Go2 (base_link z ~ 0.32m on flat ground), a sensible target
        is the *standing* height. On rough terrain (stairs / obstacles /
        ramps) the base should be **higher** so the legs can reach the
        uneven ground beneath; we therefore make the target height
        adaptive by adding a fraction of the maximum height observed in
        the height scan in front of the robot (so a step in front lifts
        the target height, which in turn encourages the controller to
        lift the legs / stand taller).

        Without the height-scan component the reward would be the same
        flat 0.32m target everywhere — which is exactly the failure
        mode the user observed: the robot learns to "stand low" on flat
        ground and then can't recover when stepping on an obstacle.
        """
        # Per-env max scan height in front of the robot. ``height_scan_buf``
        # stores the *relative* heights (scan_z - base_z - height_offset),
        # so to recover the absolute obstacle height we add the base z
        # back. We then convert to a target base height of
        # ``standing + 0.6 * max_obstacle_offset``.
        if not hasattr(self, "height_scan_buf") or self.height_scan_buf is None:
            scan_abs = torch.zeros(self.num_envs, device=self.device)
        else:
            scan_abs = self.height_scan_buf + self.base_pos[:, 2:3]
        obstacle_offset = scan_abs.max(dim=-1).values.clamp(min=0.0, max=0.25)
        target = 0.32 + 0.6 * obstacle_offset
        return torch.exp(-((self.base_pos[:, 2] - target) ** 2) / 0.02)
